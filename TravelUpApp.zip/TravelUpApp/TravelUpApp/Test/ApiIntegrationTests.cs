﻿using NUnit.Framework;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;
using System.Text;

namespace TravelUpApp.Test
{
    public class ApiIntegrationTests
    {
        private HttpClient _client;

        [SetUp]
        public void Setup()
        {
            _client = new HttpClient { BaseAddress = new Uri("http://localhost:5195/API") }; // Adjust the URL as needed
        }

        [Test]
        public async Task Get_Endpoint_ReturnsSuccess()
        {
            // Arrange
            var requestUrl = "/ItemsAPI";

            // Act
            var response = await _client.GetAsync(requestUrl);

            // Assert
            Assert.That(response.IsSuccessStatusCode, Is.True, "Expected success status code.");
        }

        [Test]
        public async Task Post_Endpoint_CreatesResource()
        {
            // Arrange
            var requestUrl = "/api/CreateItem";
            var content = new StringContent("{\"name\":\"test\"}", Encoding.UTF8, "application/json");

            // Act
            var response = await _client.PostAsync(requestUrl, content);

            // Assert
            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
        }
    }
}
