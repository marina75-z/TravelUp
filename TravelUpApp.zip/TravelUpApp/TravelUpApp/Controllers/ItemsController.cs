﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using TravelUpApp.DTO;
using TravelUpApp.Models;

namespace TravelUpApp.Controllers
{
    public class ItemsController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly string _baseUrl;
        private readonly IMapper _mapper;

        public ItemsController(HttpClient httpClient,
             IConfiguration configuration,
              IMapper mapper
            )
        {
            _httpClient = httpClient;
            _baseUrl = configuration["ApiSettings:BaseUrl"];
            _mapper= mapper;
        }

        // GET: Items
        public async Task<IActionResult> Index()
        {
            var s = $"{_baseUrl}/ItemsAPI/GetAll";
            var items = await _httpClient.GetFromJsonAsync<IEnumerable<Item>>($"{_baseUrl}/ItemsAPI/GetAll");
            var itemDtos = _mapper.Map<List<ItemDto>>(items);

            return View(itemDtos);
        }

        public async Task<IActionResult> Create()
        {
            var s = $"{_baseUrl}/ItemsAPI/GetAll";
            var items = await _httpClient.GetFromJsonAsync<IEnumerable<Item>>($"{_baseUrl}/ItemsAPI/GetAll");
            var itemDtos = _mapper.Map<List<ItemDto>>(items);

            return View(itemDtos);
        
        }

        public async Task<IActionResult> GetPartialView()
        {
            var s = $"{_baseUrl}/ItemsAPI/GetAll";
            var items = await  _httpClient.GetFromJsonAsync<IEnumerable<Item>>($"{_baseUrl}/ItemsAPI/GetAll");
            var itemDtos = _mapper.Map<List<ItemDto>>(items);

         
            return PartialView("_ItemsPartialView", itemDtos);
        }

        [HttpPost]
        public async Task<IActionResult> AddItem(ItemDto item)
        {
            var response = await _httpClient.PostAsJsonAsync($"{_baseUrl}/ItemsAPI/CreateItem", item);

            if (response.IsSuccessStatusCode)
            {
                // Optionally handle success (e.g., redirect or update view)
                return RedirectToAction("Index");
            }
            else
            {
                // Handle the error
                ModelState.AddModelError("", "Error adding item.");
                return View(item); // Return to the view with the item model
            }
        }
    }
}
