﻿using Microsoft.AspNetCore.Mvc;
using TravelUpApp.Models;
using TravelUpApp.Repositoty;

namespace TravelUpApp.API
{
    [ApiController]
    [Route("API/[controller]")]
    public class ItemsAPIController : ControllerBase
    {
        private readonly IItemRepository _itemRepository;

        public ItemsAPIController(IItemRepository itemRepository)
        {
            _itemRepository = itemRepository;
        }
        // GET: api/items
        [HttpGet]
        [HttpGet("GetAll")]
        public async Task<ActionResult<IEnumerable<Item>>> GetAll()
        {
            var items =  _itemRepository.GetAllItems();
            return Ok(items);
        }
        // GET: api/items/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Item>> GetItem(int id)
        {
            var item =  _itemRepository.GetItemById(id);
            if (item == null)
            {
                return NotFound();
            }
            return Ok(item);
        }

        [HttpPost]
        [Route("CreateItem")]
        public async Task<ActionResult<Item>> CreateItem(Item item)
        {
            var createdItem =  _itemRepository.AddItem(item);
            return CreatedAtAction(nameof(GetItem), new { id = createdItem.Id }, createdItem);
        }

        // PUT: api/items/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatedItem(int id, Item item)
        {
            if (id != item.Id)
            {
                return BadRequest();
            }

            var updated =  _itemRepository.UpdateItem(item);
            if (!updated)
            {
                return NotFound();
            }

            return NoContent();
        }

        // DELETE: api/items/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletedItem(int id)
        {
            var deleted =  _itemRepository.DeleteItem(id);
            if (!deleted)
            {
                return NotFound();
            }

            return NoContent();
        }


    }
}
