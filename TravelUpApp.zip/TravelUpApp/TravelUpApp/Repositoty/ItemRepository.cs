﻿using Microsoft.EntityFrameworkCore;
using TravelUpApp.Controllers;
using TravelUpApp.Models;

namespace TravelUpApp.Repositoty
{
    public class ItemRepository:IItemRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ItemsController> _logger;


        public ItemRepository(ApplicationDbContext context, ILogger<ItemsController> logger)
        {
            _context = context;
            _logger = logger;
        }
        public  IEnumerable<Item> GetAllItems()
        {
            try
            {
                return _context.Items.ToList();
            }
            catch (Exception ex)
            {
                // Log the exception (use a logging framework)
                _logger.LogError(ex, "Error retrieving items");
                return Enumerable.Empty<Item>(); // Return an empty list on error
            }

        }

       

        public  Item GetItemById(int id)
        {
            try
            {
                return _context.Items.Find(id);
            }
            catch (Exception ex)
            {
                // Log the exception
                _logger.LogError(ex, "Error retrieving items");
                return null; // Return null if an error occurs
            }
        }

        public Item AddItem(Item item)
        {
            try
            {
                _context.Items.Add(item);
                _context.SaveChangesAsync();
                return item;
            }
            catch (Exception ex)
            {
                // Log other exceptions
                _logger.LogError(ex, "Error adding item");
                return null; // Return null or handle accordingly
            }
        }

        public bool UpdateItem(Item item)
        {
            _context.Entry(item).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
                return true;
            }
          
            catch (Exception ex)
            {
                // Log other exceptions
                _logger.LogError(ex, "Error updating item");
                return false;
            }
        }

        public bool DeleteItem(int id)
        {
            try
            {
                var item = _context.Items.Find(id);
                if (item == null) return false;

                _context.Items.Remove(item);
                _context.SaveChanges();
                return true;
            }
           
            catch (Exception ex)
            {
                // Log other exceptions
                _logger.LogError(ex, "Error deleting item with ID");
                return false;
            }
        }
    }
}
