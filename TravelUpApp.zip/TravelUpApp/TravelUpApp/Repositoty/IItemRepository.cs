﻿using TravelUpApp.Models;

namespace TravelUpApp.Repositoty
{
    public interface IItemRepository
    {
        IEnumerable<Item> GetAllItems();
        Item GetItemById(int id);
        Item AddItem(Item item);
        bool UpdateItem(Item item);
        bool DeleteItem(int id);
    }
}
